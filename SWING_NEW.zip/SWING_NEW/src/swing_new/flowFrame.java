package swing_new;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class flowFrame extends JFrame {
	flowFrame(){
		JPanel p = new JPanel();
		p.setPreferredSize(new Dimension(250,250));
		p.setBackground(Color.GRAY);
		p.setLayout(new FlowLayout());
		
		p.add(new JButton("1"));
		p.add(new JButton("2"));
		p.add(new JButton("3"));
		p.add(new JButton("4"));
		p.add(new JButton("5"));
		
		p.setPreferredSize(new Dimension(250,250));
		p.setBackground(Color.GRAY);
		
		
		this.add(p);
		this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		this.setSize (1000, 1000);
		this.setLocationRelativeTo(null);
		this.setLayout(new FlowLayout(FlowLayout.CENTER,10,10));
		this.setVisible(true);
	}
	public static void main(String[] args) {
		new flowFrame();
	}

}

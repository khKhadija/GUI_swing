package swing_new;

public class Main {

	public static void main(String[] args) {
		launchpage l = new launchpage();
	}

}

package swing_new;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class frame extends JFrame {
	int w = 10;
	int h = 10;
	frame(){
		this.setLayout(new BorderLayout(10,10));
	JPanel	p1 = new JPanel();
	JPanel	p2 = new JPanel();
	JPanel	p3 = new JPanel();
	JPanel	p4 = new JPanel();
	JPanel	p5 = new JPanel();
	p1.setBackground(Color.red);
	p2.setBackground(Color.GREEN);
	p3.setBackground(Color.yellow);
	p4.setBackground(Color.magenta);
	p5.setBackground(Color.blue);
	p1.setPreferredSize(new Dimension(100,100));
	p2.setPreferredSize(new Dimension(100,100));
	p3.setPreferredSize(new Dimension(100,100));
	p4.setPreferredSize(new Dimension(100,100));
	p5.setPreferredSize(new Dimension(100,100));
	this.add(p1,BorderLayout.NORTH);
	this.add(p3,BorderLayout.EAST);
	this.add(p4,BorderLayout.SOUTH);
	this.add(p2,BorderLayout.WEST);
	this.add(p5,BorderLayout.CENTER);
	// ......sub panels
	JPanel	p6 = new JPanel();
	JPanel	p7 = new JPanel();
	JPanel	p8 = new JPanel();
	JPanel	p9 = new JPanel();
	JPanel	p10 = new JPanel();
	p6.setBackground(Color.black);
	p7.setBackground(Color.DARK_GRAY);
	p8.setBackground(Color.gray);
	p9.setBackground(Color.lightGray);
	p10.setBackground(Color.white);
	
	p5.setLayout(new BorderLayout());
	
	p6.setPreferredSize(new Dimension(50,50));
	p7.setPreferredSize(new Dimension(50,50));
	p8.setPreferredSize(new Dimension(50,50));
	p9.setPreferredSize(new Dimension(50,50));
	p10.setPreferredSize(new Dimension(50,50));
	p5.add(p6,BorderLayout.NORTH);
	p5.add(p7,BorderLayout.SOUTH);
	p5.add(p8,BorderLayout.WEST);
	p5.add(p9,BorderLayout.EAST);
	p5.add(p10,BorderLayout.CENTER);
		
		
		this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		this.setSize (1000, 1000);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		new frame();
	}

}

package swing_new;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class gridFrame extends JFrame {
	gridFrame(){
		this.setLayout(new GridLayout(2,2,10,10));
		
		
		
		this.add(new JButton("1"));
		this.add(new JButton("2"));
		this.add(new JButton("3"));
		this.add(new JButton("4"));
		//this.add(new JButton("5"));
		
		
		
	
		this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		this.setSize (1000, 1000);
	    this.setLocationRelativeTo(null);
		this.setVisible(true);

      }
public static void main(String[] args) {
		new gridFrame();

	}

}

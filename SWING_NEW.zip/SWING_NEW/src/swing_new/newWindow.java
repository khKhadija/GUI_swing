package swing_new;

import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class newWindow {
	JFrame frame = new JFrame();
	JLabel l1 = new JLabel("hello all");
	newWindow(){
		l1.setBounds(0, 0, 200, 200);
		l1.setFont(new Font(null,Font.PLAIN,25));
		frame.add(l1);
		
		
		
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		frame.setSize (1000, 1000);
		frame.setLayout(null);
		frame.setVisible(true);
	}
}

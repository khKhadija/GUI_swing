package swing_new;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;



public class MyFrame extends JFrame implements ActionListener{
	JButton button;
	JLabel  l1;
	MyFrame(){
		ImageIcon im2 = new ImageIcon("onepiece.png");
		ImageIcon im3 = new ImageIcon("luffy.jpg");
	    l1 = new JLabel();
	    l1.setIcon(im3);
	    l1.setBounds(150, 250,150,150);
	    l1.setVisible(false);
	    
	    
	    
	    
		button = new JButton();
	    
		button.setBounds(200, 100,250,100);
		button.addActionListener(e -> {System.out.println("U DARED TO PRESS ME");
			                            button.setEnabled(false); 
			                            l1.setVisible(true);});
		//button.addActionListener(this);
		button.setText("press me");
		button.setFocusable(false);
		button.setIcon(im2);
		//button.setHorizontalTextPosition(JButton.CENTER);
		//button.setVerticalTextPosition(JButton.BOTTOM);
		button.setBackground(Color.CYAN);
		button.setBorder(BorderFactory.createEtchedBorder());
		//button.setEnabled(false);
		
		
		
		
		this.setTitle("btngan");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//this.setResizable(true);
		this.setSize(500, 500);
        this.setVisible(true);
        this.setLayout(null);
        
        ImageIcon im = new ImageIcon("onepiece.png");
        this.setIconImage(im.getImage());
        this.getContentPane().setBackground( Color.RED);
		this.add(button);
		this.add(l1);
		

	}

	@Override
	public void actionPerformed(ActionEvent e) {
	/*	if(e.getSource()==button){
		System.out.println("U DARED TO PRESS ME");
		
		}*/}

	public static void main(String[] args) {
		new MyFrame(); 

	}
	
	
	
	
	
	
	
}

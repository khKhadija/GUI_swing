package btngan;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class frame2 extends JFrame implements MouseListener{
	JButton b1;
	JButton zombie;
    int i=1;
 public frame2(){

	JPanel p=new JPanel();
   b1=new JButton("enlarge");
   b1.setFont(new Font(null,Font.BOLD,20));
   b1.setFocusable (false);

	p.add(b1);
    
	 b1.addMouseListener(this);

	b1.setBounds (400, 800, 200, 100);


	zombie=new JButton("small zombie");

	zombie.setFont(new Font(null,Font.BOLD,20));
	zombie.setBounds(0,0,200,200);


	zombie.setBackground (Color.blue);

	zombie.setForeground(Color.GREEN);

	zombie.setEnabled(false);
    p.add(zombie);
    p.setLayout (null);
    p.add(b1);



	this.add(p);

this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
this.setSize (1000, 1000);
 this.setLocationRelativeTo(null);
    this.setVisible(true);
 }
	public static void main(String[] args) {
		new frame2();

	}
	@Override
	public void mouseClicked(MouseEvent arg0) {
		if(i<4){
			i++;
			zombie.setBounds(0,0,200*i,200*i);
		}
		if(i==4){
			i++;
			zombie.setBounds(0,0,800,800);
			zombie.setText("HUGE ZOMBIE");
			zombie.setFont(new Font(null,Font.BOLD,40));
		}
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}

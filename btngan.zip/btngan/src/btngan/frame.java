package btngan;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class frame extends JFrame implements ActionListener , MouseListener{
	JButton button1;
	JButton button2;
	frame(){
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		
		p2.setLayout(new BorderLayout());
		//p1.setLayout(new FlowLayout());
		
		button1 = new JButton("small zombie");
		button1.setBounds(0, 0,100,100);
		
		button2 = new JButton("enlarge");
		button2.setPreferredSize(new Dimension(100,100));
	 
		
		p1.add(button1);
		p2.add(button2,BorderLayout.SOUTH);
		
		button2.addMouseListener(this);
		//button1.addMouseListener(this);
		
		
		this.setTitle("btngan");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(1000,1000);
       
     
       
		this.add(p1);
        this.add(p2,BorderLayout.SOUTH);
        this.setLocationRelativeTo(null);
       // this.pack();
        this.setVisible(true);
        
	}
	
	public static void main(String[] args) {
	new frame();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		int btn=300;
	
			if(e.getSource()==button2){
				button1.setPreferredSize(new Dimension(btn,btn));
			
			
	
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getClickCount()==1){
			int btn=300;
			button1.setBounds(250, 250,btn,btn);
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}

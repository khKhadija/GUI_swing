package btngan;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class frame3 extends JFrame implements MouseListener,ActionListener{
	JButton button1;
	JButton button2;
	JButton button3;
	JButton button4;
	JButton button5;
	JPanel p1;
	int i=1;
	frame3(){
		 p1 = new JPanel();
		p1.setLayout(new BorderLayout());
		button1 = new JButton("joel");
		button2 = new JButton("tommy");
		button3 = new JButton("ellie");
		button4 = new JButton("tess");
		button5 = new JButton("rotate");
		p1.add(button1,BorderLayout.NORTH);
		p1.add(button2,BorderLayout.EAST);
		p1.add(button3,BorderLayout.SOUTH);
		p1.add(button4,BorderLayout.WEST);
		p1.add(button5,BorderLayout.CENTER);
		
		
		
		this.add(p1);
		//button5.addMouseListener(this);
		button5.addActionListener(this);
		this.setTitle("btngan");
		this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		this.setSize (1000, 1000);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
	}

   public static void main(String[] args) {
		new frame3();

		}

@Override
public void mouseClicked(MouseEvent arg0) {
	
	if(i==1){
		i++;
		p1.add(button4,BorderLayout.NORTH);
		p1.add(button1,BorderLayout.EAST);
		p1.add(button2,BorderLayout.SOUTH);
		p1.add(button3,BorderLayout.WEST);
	}
	if(i==2){
		i++;
		p1.add(button3,BorderLayout.NORTH);
		p1.add(button4,BorderLayout.EAST);
		p1.add(button1,BorderLayout.SOUTH);
		p1.add(button2,BorderLayout.WEST);
		
	}
	if(i==3){
		i++;
		p1.add(button2,BorderLayout.NORTH);
		p1.add(button3,BorderLayout.EAST);
		p1.add(button4,BorderLayout.SOUTH);
		p1.add(button1,BorderLayout.WEST);
		
	}
	
}

@Override
public void mouseEntered(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void mouseExited(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void mousePressed(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void mouseReleased(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void actionPerformed(ActionEvent e) {
	if(e.getSource() == button5) {
		String t = button1.getText();
		
		button1.setText(button4.getText());
		button4.setText(button3.getText());
		button3.setText(button2.getText());
		
		button2.setText(t);
	}
	
}
}

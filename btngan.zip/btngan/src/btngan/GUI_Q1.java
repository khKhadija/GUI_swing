package btngan;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class GUI_Q1 extends JFrame implements ActionListener {
	JPanel p1;
	JButton b1;

	JButton enlarge;
	int count = 0;

	public GUI_Q1() {

		p1 = new JPanel();
		p1.setLayout(null);
		this.getContentPane().add(p1, BorderLayout.CENTER);

		b1 = new JButton("Small Zombie");
		b1.setBounds(0, 0, 150, 150);
		p1.add(b1);

		enlarge = new JButton("enlarge");
		enlarge.addActionListener(this);
		this.getContentPane().add(enlarge, BorderLayout.SOUTH);

		this.setSize(600, 500);
		super.setDefaultCloseOperation(EXIT_ON_CLOSE);
		super.setVisible(true);

	}

	

	public static void main(String[] args) {
		GUI_Q1 f = new GUI_Q1();

	}



	@Override
	public void actionPerformed(ActionEvent e) {
		if (count == 0) {
			b1.setBounds(0, 0, 250, 250);
		} else if (count == 1) {
			b1.setBounds(0, 0, 350, 350);
		} else if (count == 2) {
			b1.setBounds(0, 0, 450, 450);
		} else {
			b1.setText("HUGE ZOMBIE");
		}

		count++;

	}

}

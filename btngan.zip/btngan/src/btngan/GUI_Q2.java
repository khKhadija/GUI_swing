package btngan;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class GUI_Q2 extends JFrame implements ActionListener {
	JPanel p1;
	JButton[] arr;

	public GUI_Q2() {

		p1 = new JPanel();
		p1.setLayout(new GridLayout(4, 4));
		p1.setBackground(Color.black);
		this.getContentPane().add(p1, BorderLayout.CENTER);

		arr = new JButton[16];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = new JButton();
			arr[i].addActionListener(this);
			p1.add(arr[i]);
		}

		super.setSize(600, 500);
		super.setDefaultCloseOperation(EXIT_ON_CLOSE);
		super.setVisible(true);

	}

	public static void main(String[] args) {
		GUI_Q2 f = new GUI_Q2();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		for (int i = 0; i < arr.length; i++) {
			arr[i].setText("");
		}
		
		
		for (int i = 0; i < arr.length; i++) {
			if (e.getSource() == arr[i]) {
				arr[i].setText("Player");
			}
		}
	}

}
